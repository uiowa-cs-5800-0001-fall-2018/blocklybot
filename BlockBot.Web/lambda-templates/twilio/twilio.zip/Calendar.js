class Calendar {
    constructor(name, id) {
        this.name = name;
        this.id = id;
    }
}

module.exports = Calendar;